var initMenuAnimation;

initMenuAnimation = function() {
  return $('.menu a').click(function(ev) {
    var currentView;
    ev.preventDefault();
    $('.selected').removeClass('selected');
    $(ev.currentTarget).parent().addClass('selected');
    currentView = $($(ev.currentTarget).attr('href'));
    currentView.show();
    return currentView.addClass('selected');
  });
};

$(function() {
  initMenuAnimation();
  Message.init();
  Listener.init();
  return Listener.listenOnce('stats', {}, function(msg) {
    return chrome.storage.local.get(['option', 'state'], function(storObj) {
      return React.renderComponent(Dashboard({
        option: storObj.option,
        state: storObj.state,
        stats: msg.stats
      }), $('#dashboard_container')[0]);
    });
  });
});
