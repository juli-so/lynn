var Dashboard, a, div, h1, h2, h3, h4, h5, h6, hr, li, ol, p, span, ul, _ref, _ref1;

_ref = React.DOM, div = _ref.div, span = _ref.span, a = _ref.a, p = _ref.p, ol = _ref.ol, ul = _ref.ul, li = _ref.li;

_ref1 = React.DOM, h1 = _ref1.h1, h2 = _ref1.h2, h3 = _ref1.h3, h4 = _ref1.h4, h5 = _ref1.h5, h6 = _ref1.h6;

hr = React.DOM.hr;

Dashboard = React.createClass({
  render: function() {
    return div({
      id: 'dashboard_content'
    }, div(null, h2(null, 'Bookmark Stats'), p(null, "Total bookmark count: " + this.props.stats.bmAmount), p(null, "" + this.props.stats.tagBmAmount + " tagged, around " + this.props.stats.tagPercent + "%"), p(null, "" + this.props.stats.noTagBmAmount + " not tagged, around " + this.props.stats.noTagPercent + "%"), div({
      className: 'five-rand'
    }, span({
      className: 'five-rand-hint'
    }, 'Five random bookmarks to explore: '), ul(null, _.map(this.props.stats.fiveRandBm, function(bm) {
      return li(null, a({
        href: bm.url
      }, bm.title));
    })))), div(null, h2(null, 'Sessions'), _.map(this.props.state.sessionMap, function(sessionRecord, sessionName) {
      return div(null, ':', sessionName, ' to invoke: ', sessionRecord.type === 'window' ? ul({
        className: 'dash-list'
      }, _.map(sessionRecord.session, function(node) {
        return li(null, a({
          href: node.url
        }, node.title));
      })) : ul(null, _.map(sessionRecord.session, function(nodeArray) {
        return ul({
          className: 'dash-list'
        }, hr({}, _.map(nodeArray, function(node) {
          return li(null, a({
            href: node.url
          }, node.title));
        })));
      })));
    })));
  }
});
